<?php
/*
Template Name: Thank You Page
*/

get_header(); ?>


<?php 
	$not_found_background_image_images = get_field( 'not_found_background_image', 'option' );
	$not_found_dataInterchangeBG = dataInterchangeImgs($not_found_background_image_images);
?>
<div class="content thank-you-wrapper" id="content" data-interchange="<?=$not_found_dataInterchangeBG;?>">
	
	<div class="grid-container align-middle text-center">
		<div class="inner-content grid-x grid-padding-x text-center align-center align-middle">	
	
			<main class="main small-12 medium-12 large-10 cell" role="main">
				
				<article class="thank-you-content">
					<section class="entry-content">
							<div class="page-heading">
							<h1 class="page-title"> 
								<?php the_title(); ?> 	
							</h1>
							<?php while( have_posts() ) : the_post(); ?>
								<div class="thank-you-content"><?php echo the_content();?></div>
							<?php endwhile; ?>
							<hr>
						</div>
						<?php 
							$three_block_featured_image = get_field( 'three_block_f.                 eatured_image', 'option' );
						?>
						<section class="three-img-block-section">
							<div class="grid-container">
								<div class="grid-x grid-padding-x three-img-block-grid-container align-middle align-center">
									<div class="cell small-12 large-12">
										<div class="grid-x grid-padding-x align-middle align-center text-center">
											<div class="cell small-12 hide-for-medium">
												<img src="<?php echo $three_block_featured_image['url']; ?>" alt="<?php echo $three_block_featured_image['alt']; ?>" />
											</div>
											<?php if ( have_rows( 'three_image_block_wrapper', 'option' ) ) : ?>
												<?php while ( have_rows( 'three_image_block_wrapper', 'option' ) ) : the_row(); ?>
													<div class="cell small-12 medium-4 large-4 ">	
														<?php $block_link = get_sub_field( 'block_link' ); ?>
														<?php $image = get_sub_field( 'image' ); ?>
														<a href="<?php echo $block_link['url']; ?>" target="<?php echo $block_link['target'];?>" title="<?=$block_link['title'];?>">
															<div class="image-block-title button primary rounded"><?php echo $block_link['title']; ?></div>
														</a>
													</div>
												<?php endwhile; ?>
											<?php else : ?>
												<?php // no rows found ?>
											<?php endif; ?>
										</div>
									</div>		
								</div>	
							</div>
						</section>	
					</section> <!-- end article section -->
			
				</article> <!-- end article -->
	
			</main> <!-- end #main -->

		</div> <!-- end #inner-content -->

	</div> <!-- end #content -->
	<?php get_footer(); ?>
</div> <!-- end .grid-container -->

