<?php 
	// This can be found @ Admin > Appearance > Customize > Sub Pages > Choose Sub Page Template
	$template_type = get_theme_mod("fmbuildr_subpage_type"); 
	$container_attr = "";
	$cell_attr = ""; 
	
	switch ($template_type) {
	
	/****
		USE this variables when making a new flexible field
	****/
		
    case "full_width_grid_10":
    	$grid_attr ="align-center grid-padding-x"; 
        $cell_attr = "small-12 medium-12 large-10";  
        $container_attr = "grid-container";             
        break; 
    case "full_width_grid":
        $cell_attr = "small-12 medium-12 large-12";
        $grid_attr =  "grid-padding-x"; 
        $container_attr = "grid-container";       
        break;
    case "full_width_grid_nc":
        $cell_attr = "small-12 medium-12 large-12";
        $grid_attr =  "";                
        $container_attr = "";       
		break;

	}
	if( is_single() ):
		$grid_attr = "align-center grid-padding-x";
		$container_attr = "";
		$cell_attr = "cell small-12 medium-12 large-12";
		endif;
	if(is_singular('procedure_post')):
		$grid_attr = "align-center grid-padding-x";
		$container_attr = "grid-container";
		$cell_attr = "cell small-12 medium-12 xmedium-12 large-10";
	endif;

	/****
		These fields are used to tag IDs on each flexible field category
	****/
	
	$column_grid_images = 0;
	$three_column = 0;
	$full_width_content = 0;
	$full_width_content_text_only = 0;
	$fifty_fifty_content = 0;
	$four_eight_content = 0; 
	$eight_four_content = 0;
	$accordion = 0; 
	$tabbed_content = 0;
	$image_slider = 0;
	$content_slider = 0;
	$video_content = 0;
	$horizontal_divider = 0;
	$contact_form_widget_ctr = 0;
	$eightColContentCount = 0;
	
	
	if( have_rows('flexible_page_sections') ): $tag = 0; ?>
			
	<?php while ( have_rows('flexible_page_sections') ) : the_row(); $tag++;?>

        <?php if ( get_row_layout() == 'column_grid_images'): $column_grid_images++; ?>
			<?php 
			$smallUp  = get_sub_field('small_up');
			$mediumUp  = get_sub_field('medium_up');
			$largeUp  = get_sub_field('large_up');
			$title = get_sub_field('grid_section_title');
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr ?> flexible-field-<?=$tag?>" id="column-grid-images-<?=$column_grid_images?>">
					<div class="grid-x <?=$grid_attr?>">
						<div class="cell <?=$cell_attr?>">	
							<h2><?=$title;?></h2>				
							<div class="grid-x grid-padding-x grid-padding-y small-up-<?=$smallUp;?> xmedium-up-<?=$mediumUp;?> large-up-<?=$largeUp;?> grid-image-cols">	
								<?php 
								$colImgs  = get_sub_field('col_grid_images');
								
								if( $colImgs ): ?>
									<div class="swiper-interior-logo-container">
										<div class="swiper-wrapper">													
									   		<?php while ( have_rows( 'col_grid_images' ) ) : the_row(); ?>
									   			<div class="swiper-slide">	
										   			<?php $grid_image = get_sub_field( 'grid_image' ); ?>
										   			<?php if ( $grid_image ) : ?>
												
										   				<div class="cell grid-image-wrapper">
										   					<img src="<?php echo $grid_image['url']; ?>" alt="<?php echo $grid_image['alt']; ?>"  width="<?=$grid_image['width'];?>" height="<?=$grid_image['height'];?>" class="image-grid-img"/>
														</div>	
													<?php endif; ?>
									   			</div>
											<?php endwhile; ?>
										</div>
									</div>
								   
								<?php endif; ?>				
							</div>
						</div>
					</div>
				</div>
			</div>
			
			
		<?php elseif ( get_row_layout() == 'anchor_links_section' ) : ?>
			<div class="anchor-links-section">
				<div class="grid-container align-center">
					<div class="grid-x grid-padding-x align-middle align-center">
						<div class="cell <?=$cell_attr?>">
							<div class="grid-x grid-padding-x anchor-links-container">
								<div class="cell small-12 large-7 links-cell">
									<?php if ( have_rows( 'anchor_links' ) ) : ?>
										<div class="links-container">
											<button class="button hide-for-large anchor-select-btn" type="button" data-toggle="anchor-dropdown">Choose a Category</button>
											<div class="anchor-pane-wrapper">
												<div class="dropdown-pane anchor-link-pane bottom" id="anchor-dropdown" data-dropdown  data-position="bottom" data-alignment="left">
													<?php while ( have_rows( 'anchor_links' ) ) : the_row(); ?>
													
														<a class="other-links" href="#<?=the_sub_field( 'anchor_link_id' );?>" title="<?=the_sub_field( 'anchor_link_title' );?>" data-smooth-scroll data-offset="200">
															<?php the_sub_field( 'anchor_link_title' ); ?>
														</a>
													<?php endwhile; ?>
												</div>
											</div>
										</div>
									<?php endif; ?>
								</div>
									
								<div class="cell large-4 show-for-large">
									<?php $anchor_image = get_sub_field( 'anchor_image' ); ?>
									<?php if ( $anchor_image ) { ?>
										<img src="<?php echo $anchor_image['url']; ?>" alt="<?php echo $anchor_image['alt']; ?>" />
									<?php } ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
        <?php elseif ( get_row_layout() == 'three_column'): $three_column++;?>

			<?php 
			$colOne = get_sub_field('column_one');
			$colTwo = get_sub_field('column_two');
			$colThree = get_sub_field('column_three');
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr ?> flexible-field-<?=$tag?>" id="three-col-<?=$three_column?>">
					<div class="grid-x <?=$grid_attr?>">
						<div class="cell <?=$cell_attr?>">		
							<div class="grid-x grid-padding-x entry-content">
								<div class="cell small-12 xmedium-4">
									<?=$colOne;?>
								</div>
								<div class="cell small-12 xmedium-4">
									<?=$colTwo;?>
								</div>
								<div class="cell small-12 xmedium-4">
									<?=$colThree;?>
								</div>												
							</div>
						</div>
					</div>	
				</div>     
			</div>
        <?php elseif( get_row_layout() == 'full_width_content' ): $full_width_content++; ?>
			<?php 
			$fullWidthContent = get_sub_field('full_width_content_area');
			$custom_css_name = get_sub_field('custom_css_name');
			$add_background_image = get_sub_field('add_background_image');
			$invert_colors = get_sub_field('invert_colors');
			$background_image = get_sub_field('background_image');
			$background_color = get_sub_field('background_color');
			$dataInterchangeBG = "";
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			if($add_background_image && $background_image ): 
				$dataInterchangeBG = dataInterchangeImgs($background_image);
			endif;						
			
			?>
				<style>		
					<?php if($invert_colors): ?>		
					#full-width-content-<?=$full_width_content?> h1,
					#full-width-content-<?=$full_width_content?> h2,
					#full-width-content-<?=$full_width_content?> h3,
					#full-width-content-<?=$full_width_content?> h4,
					#full-width-content-<?=$full_width_content?> h5,
					#full-width-content-<?=$full_width_content?> h6,
					#full-width-content-<?=$full_width_content?> p { 
						color:white;
					}
					<?php endif; ?>
					
					<?php if($background_color): ?>
					#full-width-content-<?=$full_width_content?> {
						background-color:<?=$background_color?>
					}
					<?php endif; ?>
				</style>			
		
			<div id="<?=$section_anchor_link?>" class="anchor-link-section">
				<div id="full-width-content-<?=$full_width_content?>" <?php if($dataInterchangeBG || $background_color != "#ffffff"): echo 'class="inner-bg-image flexible-field-'.$tag.'" data-interchange="'.$dataInterchangeBG.'"'; else: echo 'class="fullwidthVisual flexible-field-'.$tag.'"'; endif; ?>>
					<div class="<?=$container_attr ?> ">
						<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
						<div class="cell <?=$cell_attr?>">										
							<div class="grid-x entry-content">
								<div class="cell small-12">
									<?=$fullWidthContent;?>
								</div>
							</div>
						</div>
					</div>
					</div>		
				</div>
			</div>
        <?php elseif( get_row_layout() == 'eight_column_centered' ): $eightColContentCount++; ?>
			<?php 
			$eightColContent = get_sub_field('eight_column_content_area');
			$custom_css_name = get_sub_field('custom_css_name');
			$add_background_image = get_sub_field('add_background_image');
			$change_txt_color = get_sub_field('change_text_color');
			$newTxtColor = get_sub_field('text_color');
			$background_image = get_sub_field('background_image');
			$background_color = get_sub_field('background_color');
			$dataInterchangeBG = "";
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			if($add_background_image && $background_image ): 
				$dataInterchangeBG = dataInterchangeImgs($background_image);
			endif;						
			
			?>
				<style>		
					<?php if($invert_colors): ?>		
					#eight-col-content-<?=$eightColContent;?> h1,
					#eight-col-content-<?=$eightColContent;?> h2,
					#eight-col-content-<?=$eightColContent;?> h3,
					#eight-col-content-<?=$eightColContent;?> h4,
					#eight-col-content-<?=$eightColContent;?> h5,
					#eight-col-content-<?=$eightColContent;?> h6,
					#eight-col-content-<?=$eightColContent;?> p { 
						color:white;
					}
					<?php endif; ?>
					
					<?php if($background_color): ?>
					#eight-col-content-<?=$eightColContentCount;?> {
						background-color:<?=$background_color;?>;
					}
					<?php endif; ?>
				</style>			
		
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div id="eight-col-content-<?=$eightColContentCount;?>" <?php if($dataInterchangeBG || $background_color != "#ffffff"): echo 'class="inner-bg-image eight-col-bg-img flexible-field-'.$tag.'" data-interchange="'.$dataInterchangeBG.'"'; else: echo 'class="fullwidthVisual flexible-field-'.$tag.'"'; endif; ?>>
					<div class="<?=$container_attr ?> ">
						<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?> align-center text-center">
						<div class="cell small-10">										
							<div class="grid-x entry-content">
								<div class="cell small-12 text-center <?php if($change_txt_color == true):?> addTextStyles <?php endif; ?>" style="color:<?=$newTxtColor;?>">
									<?=$eightColContent;?>
								</div>
							</div>
						</div>
					</div>
					</div>		
				</div>
			</div>
		<?php elseif( get_row_layout() == 'full_width_content_text_only' ): $full_width_content_text_only++; ?>
			<?php 
			$fullWidthContent = get_sub_field('full_width_content_area_txt');			
			$custom_css_name = get_sub_field('custom_css_name');
			$add_background_image = get_sub_field('add_background_image');
			$invert_colors = get_sub_field('invert_colors');
			$background_image = get_sub_field('background_image');
			$background_color = get_sub_field('background_color');
			$dataInterchangeBG = "";
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );			
			if($add_background_image && $background_image ): 
				$dataInterchangeBG = dataInterchangeImgs($background_image);
			endif;						
			
			if($invert_colors): ?>
				<style>					
					#fullwidth-content-text-<?=$full_width_content_text_only?> h1,
					#fullwidth-content-text-<?=$full_width_content_text_only?> h2,
					#fullwidth-content-text-<?=$full_width_content_text_only?> h3,
					#fullwidth-content-text-<?=$full_width_content_text_only?> h4,
					#fullwidth-content-text-<?=$full_width_content_text_only?> h5,
					#fullwidth-content-text-<?=$full_width_content_text_only?> p { 
						color:white;
					}
					#fullwidth-content-text-<?=$full_width_content_text_only?> {
						background-color:<?=$background_color?>
					}
				</style>			
			<?php endif; ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div id="fullwidth-content-text-<?=$full_width_content_text_only?>" <?php if($dataInterchangeBG || $background_color != "#ffffff"): echo 'class="inner-bg-image flexible-field-'.$tag.'" data-interchange="'.$dataInterchangeBG.'"'; else: echo 'class="fullwidthVisual flexible-field-'.$tag.'"'; endif; ?>>
					<div class="<?=$container_attr?>">	
						<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
							<div class="cell <?=$cell_attr?>">	
								<div class="grid-x entry-content">
									<div class="cell small-12">
										<?=$fullWidthContent;?>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>	
			</div>
        <?php  elseif( get_row_layout() == 'fifty_fifty_content' ): $fifty_fifty_content++; ?>
			<?php 
			$ffContentLeft = get_sub_field('fifty_fifty_content_left');
			$ffContentRight = get_sub_field('fifty_fifty_content_right');
			$custom_css_name = get_sub_field('custom_css_name');	
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );				
			?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="fifty-fifty-content-<?=$fifty_fifty_content?>">
					<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
						<div class="cell <?=$cell_attr?>">	
				        	<div class="grid-x grid-padding-x entry-content" >
								<div class="cell small-12 medium-6">
									<?=$ffContentLeft;?>
								</div>
								<div class="cell small-12 medium-6">
									<?=$ffContentRight;?>
								</div>
							</div>
						</div>
					</div>
				</div>		
			</div>
		<?php elseif (get_row_layout() == 'four_eight_content'): $four_eight_content++; ?>
			<?php 
			$feContentLeft = get_sub_field('four_eight_content_left');
			$feContentRight = get_sub_field('four_eight_content_right');
			$four_eight_swap_for_mobile = get_sub_field('four_eight_swap_for_mobile');
			$custom_css_name = get_sub_field('$custom_css_name');	
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			if($four_eight_swap_for_mobile):
			?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="four-eight-content-<?=$four_eight_content?>">
					<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
						<div class="cell <?=$cell_attr?>">	
				        	<div class="grid-x grid-padding-x entry-content" >
								<div class="cell small-12 xmedium-8 xmedium-order-2">
									<?=$feContentRight;?>
								</div>							
								<div class="cell small-12 xmedium-4 xmedium-order-1">
									<?=$feContentLeft;?>
								</div>
							</div>	
						</div>
					</div>
				</div>	
			</div>		
			<?php else: ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="four-eight-content-<?=$four_eight_content?>">
					<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
						<div class="cell <?=$cell_attr?>">				
				        	<div class="grid-x grid-padding-x entry-content">
								<div class="cell small-12 xmedium-4">
									<?=$feContentLeft;?>
								</div>
								<div class="cell small-12 xmedium-8">
									<?=$feContentRight;?>
								</div>
							</div>	
						</div>
					</div>	
				</div>
			</div>			
			<?php endif; ?>
			
		<?php elseif (get_row_layout() == 'eight_four_content'): $eight_four_content++; ?>
			<?php 
			$efContentLeft = get_sub_field('eight_four_content_left');
			$efContentRight = get_sub_field('eight_four_content_right');
			$eight_four_swap_for_mobile = get_sub_field('eight_four_swap_for_mobile');
			$custom_css_name = get_sub_field('custom_css_name');
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			if($eight_four_swap_for_mobile):
			?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="eight-four-content-<?=$eight_four_content?>">
					<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
						<div class="cell <?=$cell_attr?>">	
				        	<div class="grid-x grid-padding-x entry-content">
								<div class="cell small-12 xmedium-4 xmedium-order-2">
									<?=$efContentRight;?>
								</div>			        	
								<div class="cell small-12 xmedium-8 xmedium-order-1">
									<?=$efContentLeft;?>
								</div>
							</div>	
						</div>
					</div>
				</div>
			</div>
			<?php else: ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="eight-four-content-<?=$eight_four_content?>">
		 			<div class="grid-x <?=$grid_attr?> <?=$custom_css_name?>">
						<div class="cell <?=$cell_attr?>">	       	
				        	<div class="grid-x grid-padding-x entry-content">
								<div class="cell small-12 xmedium-8">
									<?=$efContentLeft;?>
								</div>
								<div class="cell small-12 xmedium-4">
									<?=$efContentRight;?>
								</div>
							</div>	
						</div>
		 			</div>
				</div>	
			</div>				
			<?php endif; ?>	
		
		<?php elseif(get_row_layout() == 'three_image_block_layout'): ?>
			<?php 
				$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			?>
			<section id="<?=$section_anchor_link;?>" class="three-img-block-section anchor-link-section">
				<div class="grid-container">
					<div class="grid-x grid-padding-x three-img-block-grid-container align-middle align-center">
						<div class="cell small-12 large-10">
							<div class="grid-x grid-padding-x align-middle align-center text-center cell-background">
								<?php if ( have_rows( 'image_block_wrapper') ) : ?>
									<div class="swiper-container">
										<div class="swiper-wrapper">
											<?php while ( have_rows( 'image_block_wrapper' ) ) : the_row(); ?>
												<div class="swiper-slide">	
													<?php $image_title = get_sub_field( 'title' ); ?>
													<?php $block_link = get_sub_field( 'block_link' ); ?>
													<?php $image = get_sub_field( 'image' ); ?>
													<a href="<?php echo $block_link['url']; ?>" target="<?php echo $block_link['target'];?>" title="<?=$block_link['title'];?>">
														<div class="image-block-image"><img class="cell" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" /></div>
														<div class="image-block-title"><?php echo $image_title; ?></div>
														<div class="image-block-button hollow button primary rounded"><?php echo $block_link['title']; ?></div>
													</a>
												</div>
											<?php endwhile; ?>
										</div>
										<div class="swiper-scrollbar"></div>
									</div>
								<?php else : ?>
									<?php // no rows found ?>
								<?php endif; ?>
							</div>
						</div>		
					</div>	
				</div>
			</section>	
		
		
		<?php elseif (get_row_layout() == 'accordion'): $accordion++;?>		
			<?php 
				$accordionTitle = get_sub_field('accordion_title');
				$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="accordion-content-<?=$accordion?>">
					<div class="grid-x <?=$grid_attr?>">
					<div class="cell <?=$cell_attr?>">	
						<?php if ($accordionTitle):?>
							<h3><?=$accordionTitle;?></h3>
						<?php endif;?>
						<?php if( have_rows('items') ):?>
						<ul class="accordion" data-accordion>
							
							<?php $ic = 0; while ( have_rows('items') ) : the_row(); $ic++;?>
							<?php // set up items for accordions and set the first to is-active
							$itemTitle = get_sub_field('item_title');
							$itemContent = get_sub_field('item_content');
							?>
							  <li class="accordion-item <?php if ($ic==1){ echo 'is-active';}?>" data-accordion-item>
							    <a href="#" class="accordion-title"><?=$itemTitle;?></a>
							    <div class="accordion-content" data-tab-content>
							      <?=$itemContent;?>
							    </div>
							  </li>						
						
						    <?php endwhile;?>
						</ul>	
						<?php endif;?>
					</div>
				</div>
				</div>
			</div>
		<?php elseif (get_row_layout() == 'tabbed_content'): $tabbed_content++; ?>
		<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="tabbed-content-<?=$tabbed_content?>">
					<div class="grid-x <?=$grid_attr?>">
						<div class="cell <?=$cell_attr?>">			
							<div class="grid-x entry-content">					
						<div class="cell small-12">
							<?php $tabbedAreaTitle = get_sub_field('tab_content_title');?>
							<h2><?=$tabbedAreaTitle;?></h2>
							
							<?php if( have_rows('tabs') ):?>
								<ul class="tabs" data-tabs id="<?=$tabbedAreaTitle;?>-content">
							    <?php $tabCount = 0; while ( have_rows('tabs') ) : the_row(); $tabCount++;?>
									<?php $tabTitle = get_sub_field('tab');?>
									<li class="tabs-title <?php if ($tabCount == 1):?>is-active<?php endif;?>"><a id="<?='panel'.$tabCount.'-label';?>" href="#panel<?=$tabCount;?>"><?=$tabTitle;?></a></li>
							    <?php endwhile;?>
							    </ul>
							<?php endif;?>	  
							<?php if( have_rows('tabs') ):?>
							    <div class="tabs-content" data-tabs-content="<?=$tabbedAreaTitle;?>-content">
							    <?php $tabCount = 0; while ( have_rows('tabs') ) : the_row(); $tabCount++;?>
							    	<?php $tabContent = get_sub_field('tab_content');?>
							    	<div id="panel<?=$tabCount;?>" class="tabs-panel <?php if ($tabCount == 1):?>is-active<?php endif;?>"><?=$tabContent;?></div>
								    	
								<?php endwhile; ?>
								</div>					
							<?php endif;?>
						</div>
					</div>
						</div>
					</div>
				</div>
			</div>
		<?php elseif (get_row_layout() == 'image_slider'): $image_slider++; ?>
			<?php 
				$slideshow_title = get_sub_field('slideshow_title');
				$enable_arrows = get_sub_field('enable_arrows');
				$enable_dots = get_sub_field('enable_dots');		        		       
				$enable_scrollbar = get_sub_field('enable_scrollbar');
		        		        
/*
				$enable_captions = get_sub_field('enable_captions');
		        $arrows  = ($enable_arrows ? "true" : "false"); // returns true
		        $dots  = ($enable_dots ? "true" : "false"); // returns true		       
		        $adapt = ($adaptive_height ? "true" : "false"); // returns true
		        $wrap  = ($wrap_around ? "true" : "false"); // returns true
				$the_cell_width = ($cell_width == "specify" ? get_sub_field('specify_width'): $cell_width ); 
*/
				
				?>
			<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="image-slide-<?=$image_slider?>">	
				<div class="grid-x <?=$grid_attr?>">
				<div class="cell <?=$cell_attr?>">					
			       <?php if($slideshow_title): ?><h2><?php echo get_sub_field('slideshow_title');?></h2><?php endif; ?>				
					<?php  $images = get_sub_field('slides'); 						
						if( $images ): ?>
						<?php $slc = 0; ?>
						<div class="sub-page-carousel swiper-container" id="img-slider-<?=$image_slider?>" >
						        <!-- Additional required wrapper -->
							<div class="swiper-wrapper">
						        <?php foreach( $images as $image ): $slc++; ?>
						           	<div class="swiper-slide">						               
						               <img src="<?php echo $image['url']; ?>" style="width:100%" alt="<?php echo $image['alt']; ?>" />
						               
						                <?php if($enable_captions):?>
						                	<?php if($image['caption']): ?>
												<div class="slide-caption animated fadeInUp text-center" id="slide-caption-<?=$randId?>"><?php echo $image['caption']; ?></div>
											<?php endif; ?>
						                 <?php endif; ?>
						           	</div>
						        <?php endforeach; ?>
							</div>
							
							<?php if($enable_dots): ?>
								<!-- If we need pagination -->
								<div class="swiper-pagination"></div>
							<?php endif; ?>	
							  <!-- If we need navigation buttons -->
							<?php if($enable_arrows): ?>
								<div class="swiper-button-prev"></div>
								<div class="swiper-button-next"></div>
							<?php endif; ?>							

							<?php if($enable_scrollbar): ?>								 
								<!-- If we need scrollbar -->
								<div class="swiper-scrollbar"></div> 
							<?php endif; ?>
								
						</div>
						<?php endif; ?>
				</div>
			</div>
			</div>	
			<script type="text/javascript">	
				window.addEventListener( 'load', function() {				
					var carouselImg<?=$image_slider?> = jQuery('#img-slider-<?=$image_slider?>');
						var mySwiper = new Swiper('#img-slider-<?=$image_slider?>', {						   
							// Optional parameters
							direction: 'horizontal',
							loop: true,
							autoHeight: true,
							slidesPerView: 1,
							spaceBetween: 10,
							
							 // If we need pagination
						    pagination: {
						      el: '.swiper-pagination',
						      clickable: true,	      
						    },
						    // Navigation arrows
						    navigation: {
						      nextEl: '.swiper-button-next',
						      prevEl: '.swiper-button-prev',
						    },
						
						    // And if we need scrollbar
						    scrollbar: {
						      el: '.swiper-scrollbar',
						      draggable: true,
						    },						    
						    
						});

						
				});				
			</script>	
									
		<?php elseif (get_row_layout() == 'content_slider'): $content_slider++; ?>
			<?php 
				$slideshow_title = get_sub_field('slideshow_title');
				$enable_arrows = get_sub_field('enable_arrows');
				$enable_dots = get_sub_field('enable_dots');		        		       
				$enable_scrollbar = get_sub_field('enable_scrollbar');
		        
		        
/*
		        $arrows  = ($enable_arrows ? "true" : "false"); // returns true
		        $dots  = ($enable_dots ? "true" : "false"); // returns true
		        $drag  = ($draggable ? "true" : "false"); // returns true
		        $adapt = ($adaptive_height ? "true" : "false"); // returns true
		        $wrap  = ($wrap_around ? "true" : "false"); // returns true
				$the_cell_width = ($cell_width == "specify" ? get_sub_field('specify_width'): $cell_width );
*/ ?>
			<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="content-slider-<?=$content_slider?>">	
				<div class="grid-x <?=$grid_attr?>">
				<div class="cell <?=$cell_attr?>">	
		
					<?php if($slideshow_title): ?><h2><?php echo get_sub_field('slideshow_title');?></h2><?php endif; ?>
	
					<?php if( have_rows('slides') ):?>
						<?php $randId = rand(1,999); ?>
						<div class="slider-<?=$randId?> sub-page-carousel"  id="content-sliders-<?=$content_slider?>">
							
							<div class="swiper-wrapper">
								<?php $slc = 0; while ( have_rows('slides') ) : the_row(); 
									$slideContent = get_sub_field('slide_content');	 ?>
									<div class="swiper-slide" style="width:<?=$the_cell_width?>">	
										<?=$slideContent;?>
									</div>
								<?php $slc++; endwhile;?>
							</div>
							
							<?php if($enable_dots): ?>
								<!-- If we need pagination -->
								<div class="swiper-pagination-content"></div>
							<?php endif; ?>	
							  <!-- If we need navigation buttons -->
							<?php if($enable_arrows): ?>
								<div class="swiper-button-prev"></div>
								<div class="swiper-button-next"></div>
							<?php endif; ?>							

							<?php if($enable_scrollbar): ?>								 
								<!-- If we need scrollbar -->
								<div class="swiper-scrollbar-content"></div> 
							<?php endif; ?>
							
						</div>		
					<?php endif;?>
				</div>
			</div>	
			</div>
			<script type="text/javascript">	
				window.addEventListener( 'load', function() {				


					var carouselCont<?=$content_slider?> = jQuery('#content-sliders-<?=$content_slider?>');
					var mySwiper = new Swiper('#content-sliders-<?=$content_slider?>', {						   
						// Optional parameters
						direction: 'horizontal',
						loop: true,
						autoHeight: true,
						slidesPerView: 1,
						//spaceBetween: 10,
						
						 // If we need pagination
					    pagination: {
					      el: '.swiper-pagination-content',
					      clickable: true,	      
					    },
					    // Navigation arrows
					    navigation: {
					      nextEl: '.swiper-button-next',
					      prevEl: '.swiper-button-prev',
					    },
					
					    // And if we need scrollbar
					    scrollbar: {
					      el: '.swiper-scrollbar-content',
					      draggable: true,
					    },						    
					    
					});
				});				
			</script>		
			
		<?php elseif(get_row_layout() == 'video_content'): $video_content++; ?>
		<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="video-content-<?=$video_content?>">	
					<div class="grid-x <?=$grid_attr?>">
					<div class="cell <?=$cell_attr?>">	
						<?php if(have_rows('videos')): $ctr = 0; ?>
							<div class="grid-x grid-padding-x" data-equalizer data-equalize-on="medium">
							<?php while(have_rows('videos')): the_row(); $ctr++; ?>
								<?php 
									$title = get_sub_field('title');
									$link = get_sub_field('link');
									$image = get_sub_field('image');										
								?>
								<div class="cell small-12 xsmall-6 medium-6 large-4 float-left">
								  <div data-equalizer-watch>
									<div class="text-center" style="line-height: 1.2; padding-bottom:20px;">
										<a href="<?php echo $link?>" data-fancybox="videos">
										<p><img src="<?php echo $image['url']?>" height="<?php echo $image['height']?>" width="<?php echo $image['width']?>"></p>
										<span><?php echo $title; ?></span>
										</a>
									</div>
								  </div>
								</div>
							<?php endwhile; ?>
						</div>
						<?php endif; ?>
					</div>
				</div>							
				</div>
			</div>
		<?php elseif (get_row_layout()== 'horizontal_divider'): $horizontal_divider++; ?>
		<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="hr-<?=$horizontal_divider?>">	
					<div class="grid-x <?=$grid_attr?>">
						<div class="cell <?=$cell_attr?>">	
							<hr/>
						</div>
					</div>
				</div>
			</div>
		<?php elseif (get_row_layout()== 'contact_form_widget'): $contact_form_widget_ctr++; ?>
			<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<?php $contact_form_widget = get_sub_field('contact_form_widget'); ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>" id="contact-form-widget-<?=$contact_form_widget_ctr?>">	
					<div class="grid-x <?=$grid_attr?>">
					<div class="cell <?=$cell_attr?>">				
						<div class="grid-x entry-content contact-form-widget-wrapper ">
					<div class="cell small-12">
						<div class="widget-contact-form-container"><?php echo do_shortcode($contact_form_widget);?></div>
					</div>
				</div>	
					</div>
				</div>
				</div>
			</div>
		<?php elseif ( get_row_layout() == 'full_width_widgets'):?>
			<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<?php $select = get_sub_field('select_widget');?>
			<?php if ($select === 'contactForm') : ?>
				<?php $contactImage = get_field( 'contact_form_background_image', 'option' ); 
					  $interchangeImgs = dataInterchangeImgs($contactImage);
					  $contactForm = get_field('contact_form_shortcode', 'option');
				?>

				<section id="<?=$section_anchor_link;?>" class="full-width-contact-form-widget anchor-link-section">
					<div class="grid-container contact-grid-container">
						<div class="grid-x grid-padding-x align-center contact-grid-container">
							<div class="cell small-12 medium-12 large-10 contact-form-wrapper">	
								<?=$contactForm;?>
							</div>
						</div>	
					</div>    
				</section>	

			<?php elseif($select === 'reviewsBlock') : ?>
				<?php 
					$reviewsContent = get_field('reviews_content', 'option');
					$reviewsBgImgs = get_field( 'reviews_background_image', 'option' );
					$interchangeImgs = dataInterchangeImgs($reviewsBgImgs);
					$reviewsButton = get_field( 'reviews_button_text', 'option' );
					$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
				?>
				<section id="<?=$section_anchor_link;?>" class="reviews-section anchor-link-section">
					<div class="grid-x reviews-grid-container align-middle align-center" data-interchange="<?=$interchangeImgs;?>">
					<div class="cell small-12 medium-12 large-12 cell-wrapper">	
						<div class="grid-x grid-container grid-padding-x align-middle align-right entry-content">
							<div class="cell small-12 medium-10 large-5 text-left">
								<?=$reviewsContent;?>
								<a class="white button rounded" href="<?php echo $reviewsButton['url']; ?>" target="<?php echo $reviewsButton['target']; ?>"><?php echo $reviewsButton['title']; ?></a>
							</div>
						</div>
					</div>
				</div>	
				</section>		
			<?php elseif($select === 'requestConsultation') : ?>
				<?php 
					$requestConsultContent = get_field('request_consultation_content', 'option');
					$requestConsultBgImgs = get_field( 'request_consultation_background_image', 'option' );
					$interchangeImgs = dataInterchangeImgs($requestConsultBgImgs);
					$requestConsultButton = get_field( 'request_consultation_button_text', 'option' );
					$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
				?>
				<section id="<?=$section_anchor_link;?>" class="request-consultation-widget-section anchor-link-section">
					<div class="grid-x request-consult-grid-container align-middle align-center" data-interchange="<?=$interchangeImgs;?>">
					<div class="cell small-12 medium-12 large-12 cell-wrapper">	
						<div class="grid-x grid-container grid-padding-x align-middle align-center entry-content">
							<div class="cell small-12 medium-10 large-5 text-center">
								<?=$requestConsultContent;?>
								<a class="white button rounded" href="<?php echo $requestConsultButton['url']; ?>" target="<?php echo $requestConsultButton['target']; ?>"><?php echo $requestConsultButton['title']; ?></a>
							</div>
						</div>
					</div>
				</div>	
			</section>		
			<?php elseif($select === 'beforeAfters') : ?>
				<?php 
					$baImageLeft = get_field( 'before_after_image_left', 'option' );
					$baImageRight = get_field( 'before_after_image_right', 'option' );;

					$baButton = get_field( 'before_after_widget_button', 'option' );
					$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
					
					$changeBAs = get_sub_field( 'change_before_and_afters' );
					$new_before_image = get_sub_field( 'before_image' );
					$new_after_image = get_sub_field( 'after_image' );
					$new_button_link = get_sub_field( 'button_link' );
					
				?>
				<section id="<?=$section_anchor_link;?>" class="before-after-widget-section anchor-link-section">
					<div class="grid-container align-center">
						<div class="grid-x before-after-grid-container align-middle align-center text-cenetr">
							<?php if ($changeBAs == true) : ?>
								<div class="cell small-12  medium-6 large-6 cell-left small-order-1 medium-order-1">
									<img src="<?php echo $new_before_image['url']; ?>" alt="<?php echo $new_before_image['alt']; ?>"/>
								</div>
								<div class="cell small-12  medium-6 large-6 cell-right small-order-3 medium-order-2">
									<img src="<?php echo $new_after_image['url']; ?>" alt="<?php echo $new_after_image['alt']; ?>"/>
								</div>
								<div class="cell small-12 medium-12 large-12 cell-button small-order-2 medium-order-3">	
									<a class="primary button rounded" href="<?php echo $new_button_link['url']; ?>" target="<?php echo $new_button_link['target']; ?>"><?php echo $new_button_link['title']; ?></a>
								</div>
							
							
							<?php else: ?>
							
							
								<div class="cell small-12  medium-6 large-6 cell-left small-order-1 medium-order-1" >
									<img src="<?php echo $baImageLeft['url']; ?>" alt="<?php echo $baImageLeft['alt']; ?>"/>
								</div>
								<div class="cell small-12  medium-6 large-6 cell-right small-order-3 medium-order-2" >
									<img src="<?php echo $baImageRight['url']; ?>" alt="<?php echo $baImageRight['alt']; ?>"/>
								</div>
								<div class="cell small-12 medium-12 large-12 cell-button small-order-2 medium-order-3">	
									<a class="primary button rounded" href="<?php echo $baButton['url']; ?>" target="<?php echo $baButton['target']; ?>"><?php echo $baButton['title']; ?></a>
								</div>
							<?php endif;?>
						</div>	
					</div>
				</section>			
			<?php elseif($select === 'threeImageBlock') : ?>
				<?php 
					$three_block_featured_image = get_field( 'three_block_featured_image', 'option' );
					$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
				?>
				<section id="<?=$section_anchor_link;?>" class="three-img-block-section anchor-link-section">
					<div class="grid-container">
						<div class="grid-x grid-padding-x three-img-block-grid-container align-middle align-center">
							<div class="cell small-12 large-10">
								<div class="grid-x grid-padding-x align-middle align-center text-center cell-background">
									<div class="cell small-12 hide-for-medium">
										<img src="<?php echo $three_block_featured_image['url']; ?>" alt="<?php echo $three_block_featured_image['alt']; ?>" />
									</div>
									<?php if ( have_rows( 'three_image_block_wrapper', 'option' ) ) : ?>
										<div class="swiper-container">
											<div class="swiper-wrapper">
												<?php while ( have_rows( 'three_image_block_wrapper', 'option' ) ) : the_row(); ?>
													<div class="swiper-slide">	
														<?php $image_title = get_sub_field( 'title' ); ?>
														<?php $block_link = get_sub_field( 'block_link' ); ?>
														<?php $image = get_sub_field( 'image' ); ?>
														<a href="<?php echo $block_link['url']; ?>" target="<?php echo $block_link['target'];?>" title="<?=$block_link['title'];?>">
															<div class="image-block-image"><img class="cell" src="<?php echo $image['url']; ?>" alt="<?php echo $image['alt']; ?>" /></div>
															<div class="image-block-title"><?php echo $image_title; ?></div>
															<div class="image-block-button hollow button primary rounded"><?php echo $block_link['title']; ?></div>
														</a>
													</div>
												<?php endwhile; ?>
											</div>
											<div class="swiper-scrollbar"></div>
										</div>
									<?php else : ?>
										<?php // no rows found ?>
									<?php endif; ?>
								</div>
							</div>		
						</div>	
					</div>
				</section>	
			<?php endif; ?>			
			
		<?php elseif ( get_row_layout() == 'documents_grid' ) : ?>
		<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<section id="<?=$section_anchor_link;?>" class="documents-grid-section anchor-link-section">
				<div class="<?=$container_attr?>">
					<div class="grid-x <?=$grid_attr?>">
						<div class="cell <?=$cell_attr?>">
							<?php if ( have_rows( 'documents' ) ) : ?>
								<?php while ( have_rows( 'documents' ) ) : the_row(); ?>
								<div class="grid-x document-wrapper align-middle">
									<div class="cell small-10 medium-7 large-9">
										<a href="<?php echo $attach_file['url']; ?>" download title="<?php echo $attach_file['filename']; ?>">
											<div class="file-icon"><?php the_sub_field( 'file_icon' ); ?></div>
											<div class="file-title"><?php the_sub_field( 'file_title' ); ?></div>
										</a>
									</div>
									<div class="cell small-8 medium-5 large-3 download-file-wrap">
										<?php $attach_file = get_sub_field( 'attach_file' ); ?>
										<?php if ( $attach_file ) { ?>
											<a href="<?php echo $attach_file['url']; ?>" download class="button primary rounded download-btn" title="<?php echo $attach_file['filename']; ?>">Download</a>
										<?php } ?>
									</div>
								</div>
								<?php endwhile; ?>
							<?php else : ?>
								<?php // no rows found ?>
							<?php endif; ?>	
						</div>
					</div>
				</div>		
			</section>
			
		<?php elseif (get_row_layout()== 'widgets'):?>
		<?php $section_anchor_link = get_sub_field( 'section_anchor_link_id' ); ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="<?=$container_attr?> flexible-field-<?=$tag?>">	
					<div class="grid-x <?=$grid_attr?>">
						<div class="cell <?=$cell_attr?>">			
							<div class="flexible-widgets twocol-widget">
					<div class="grid-x entry-content">
						<?php if(have_rows('widgets')): $ctr = 0; ?>
							<?php while(have_rows('widgets')): the_row(); $ctr++; ?>
								<div class="cell small-12 medium-6 widgeter widgeter-<?=$ctr?>">
									<?php $add_widget = get_sub_field('add_widget'); ?>							
									
									<?php if($add_widget == "4") :								
										$relatedGallery = get_sub_field('related_gallery');
										$gal_featured_image = get_sub_field('gal_featured_image'); ?>
													
										
									    <?php if( $relatedGallery ): ?>
									    <div class="widgetBoxWrap grid-x align-middle widget-gallery text-center">
									    <div class="cell small-12 widgetBox wYesBg  custTextWidget widgetBg text-center ">
									 		
										    <?php foreach( $relatedGallery as $post): // variable must be called $post (IMPORTANT) ?>
										    <?php setup_postdata($post); ?>
										        <?php $altTitle = get_field('alt_title');   ?>							     
												
												<?php if( have_rows('patient_galleries') ): ?>
												<div class="grid-y">
													<?php while ( have_rows('patient_galleries') ) : the_row(); ?>
														<?php $showOnArchive  = get_sub_field('show_in_archive');?>						
															<?php if( $showOnArchive): ?>
																				
																<div class="cell auto"><a href="<?php echo get_permalink(); ?>"><img class="alignnone" src="<?=$gal_featured_image['url'];?>" 
																alt="<?=$gal_featured_image['alt'];?>" width="<?=$gal_featured_image['width'];?>" height="<?=$gal_featured_image['height'];?>"/></a></div><div class="cell shrink"><a href="<?php echo get_permalink(); ?> " class="button primary expanded">VIEW THE GALLERY </a></div>				
																	
															<?php endif; ?>				
													<?php endwhile; ?>	
												</div>		
												<?php endif; ?>
											    <?php endforeach; ?>
										    
										    <?php wp_reset_postdata(); // IMPORTANT - reset the $post object so the rest of the page works correctly ?>
									    </div>
									  </div>
									  <?php endif; ?>
		
										
									<?php else: ?>
										<?php echo do_shortcode($add_widget);?>
									<?php endif; ?>
								</div>
							<?php endwhile; ?>
						<?php endif; ?>	
					</div>
				</div>	
						</div>
					</div>
				</div>
			</div>
		<?php elseif (get_row_layout()== 'full_custom_widget'):
				$full_custom_widget = get_sub_field('custom_widget'); 
				$before_and_after_cta = get_sub_field('before_and_after_cta_name');
				$before_and_after_cta_link = get_sub_field('before_and_after_cta_link');
			?>

			<?php echo do_shortcode($full_custom_widget);					
				if($before_and_after_cta_link != "/" && $before_and_after_cta ):
			?>
				<script type="text/javascript">
					jQuery("#widget-banda-button a").attr("href","<?=$before_and_after_cta_link;?>");
					jQuery("#widget-banda-button a").html('<?=$before_and_after_cta?>')
				</script>
				<?php endif; ?>		

		<?php elseif (get_row_layout()== 'two_by_two'): ?>
		<?php 
			$section_title = get_sub_field('section_title');
			$enable_dark_mode = get_sub_field('enable_dark_mode');	
			$mode = "light-mode";
			$section_anchor_link = get_sub_field( 'section_anchor_link_id' );
			$change_bg = get_sub_field('change_background_color');
			$new_bg_color = get_sub_field('background_color');
			
			if($enable_dark_mode):
				$mode = "dark-mode";
			endif;
		
			if(have_rows('two_by_two_content')): $ctr_two = 0; ?>
			<div id="<?=$section_anchor_link;?>" class="anchor-link-section">
				<div class="two-by-two-section <?=$mode?>" <?php if($change_bg == true): ?> style="background-color: <?=$new_bg_color;?>; padding: 50px 0;" <?php endif;?>>
					<div class="<?=$container_attr?>">
						<div class="grid-x <?=$grid_attr?>">
							<div class="cell <?=$cell_attr?>">	
								<div class="grid-x">
									<?php while(have_rows('two_by_two_content')): the_row(); $ctr_two++; 
										$title = get_sub_field('title');
										$two_by_content = get_sub_field('two_by_content');
									?>
										<div class="cell small-12 medium-6 large-6 grid-cell grid-cell-<?=$ctr_two?>">
											<?=$two_by_content?>
										</div>								
									<?php endwhile; ?>
								</div>	
							</div>
						</div>					
					</div>
				</div>
			</div>					
				
		<?php endif; ?>				
								

        <?php endif;?>

    <?php endwhile;?>

<?php endif;?>