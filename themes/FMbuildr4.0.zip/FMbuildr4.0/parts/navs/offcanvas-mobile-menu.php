<?php
/**
 * The template part for displaying offcanvas content
 *
 * For more info: http://jointswp.com/docs/off-canvas-menu/
 */
?>

<?php 
	$mobileNavStyle = get_theme_mod("offcanvas_select_setting_id"); 
	$tabletNavStyle = get_theme_mod("offcanvas_select_setting_tablet_id"); 
	$mobileTransition = get_theme_mod("offcanvas_transition_id");
	$tabletTransition = get_theme_mod("offcanvas_transition_tablet_id");
	$logo = get_field('mobile_logo','options');
	$officeName = get_field('office_name','options');
	$secondOfficeName = get_field('second_office_name','options');
	$secondPhone = get_field('second_office_phone_number','options');
	$phone = get_field('phone_number','options');
?> 


<div class="off-canvas position-left" data-mobile="<?php echo $mobileNavStyle." ".$mobileTransition ; ?>" data-tablet="<?php echo $tabletNavStyle." ".$tabletTransition; ?>" id="off-canvas" data-off-canvas data-transition="overlap">
	<?php 
		$phone = get_field('phone_number','option');
		$off_canvas_cta = get_field('off_canvas_cta','options');
		$off_canvas_cta_link = get_field('off_canvas_cta_link','options');
	?>
<div class="grid-y" style="height:100%">
		<div class="shrink cell top-cell" style="overflow-x: hidden; overflow-y: hidden;">	
				<?php if ( have_rows( 'mobile_featured_services', 'option' ) ): ?>
					<?php while ( have_rows( 'mobile_featured_services', 'option' ) ) : the_row(); ?>
						<?php if ( get_row_layout() == 'mobile_featured_services' ) : ?>
							<?php if ( have_rows( 'featured_services' ) ) : ?>
								<div class="mobile-procedures-wrapper">
									<div class="mobile-swiper-container">
										<div class="swiper-wrapper">
											<?php while ( have_rows( 'featured_services' ) ) : the_row(); ?>
												<div class="swiper-slide">	
													
													<?php $service_background_image = get_sub_field( 'service_background_image' ); ?>
														
													<div class="procedure-bg-img" style="background-image: url(<?=$service_background_image['url'];?>);"></div>
													<?php $service_link = get_sub_field( 'service_link' ); ?>
													<div class="grid-container procedure-grid-container">
														<div class="grid-x align-middle procedures-content-wrapper">
															<div class="procedure-title">
																<a href="<?php echo $service_link['url']; ?>" target="<?php echo $service_link['target']; ?>">
																	<span class="slider-title"><?php echo $service_link['title']; ?></span>
																</a>
															</div>
														</div>
													</div>
												</div>
											<?php endwhile; ?>
										</div>
										<div class="mobile-swiper-scrollbar"></div>
									</div>
								</div>
							<?php else : ?>
								<?php // no rows found ?>
							<?php endif; ?>
						<?php endif; ?>
					<?php endwhile; ?>
				<?php else: ?>
					<?php // no layouts found ?>
				<?php endif; ?>
			
		</div>
	<div class="auto cell middle-cell">	
		<div class="off-cv-wrapper"> 
			<?php joints_curtain_nav(); ?>
		</div>
	</div>
		
		<div class="cell shrink bottom-cell">	
			<div class="off-cv-social-wrapper">
					<?php echo do_shortcode('[offcanvasSocial]'); ?>
				</div>		
			<div class="off-canvas-cta-button">
				<a href="<?=$off_canvas_cta_link?>" class="button white rounded"><?=$off_canvas_cta?></a>
			</div>
		</div>
	</div>
</div>

<div class="off-canvas position-right" data-mobile="<?php echo $mobileNavStyle." ".$mobileTransition ; ?>" data-tablet="<?php echo $tabletNavStyle." ".$tabletTransition; ?>" id="off-canvas-phone" data-off-canvas data-transition="overlap">
	<?php 
		$phone = get_field('phone_number','option');
		$off_canvas_cta = get_field('off_canvas_cta','options');
		$off_canvas_cta_link = get_field('off_canvas_cta_link','options');
	?>
<div class="grid-y" style="height:100%">
		<div class="auto cell top-cell" style="overflow-x: hidden;">	
			<div class="off-cv-wrapper grid-x grid-padding-x"> 
				<div class="cell small-12 text-center" id="location-tel-links-nav">
						<span class="location-name"><?= $officeName; ?></span><a class="button white rounded" href="tel:+1<?php echo _phone_num($phone);?>"><?=$phone;?></a>
						<?php if ( have_rows( 'add_office_name_number', 'option' ) ) : ?>
							<?php while ( have_rows( 'add_office_name_number', 'option' ) ) : the_row(); ?>
								<?php $phoneNums = get_sub_field( 'office_phone_number' ); ?>
								<span class="location-name"><?php the_sub_field( 'office_name' ); ?></span>
								<a class="button white rounded" href="tel:+1<?php echo _phone_num($phoneNums);?>"><?=$phoneNums;?></a>
							<?php endwhile; ?>
						<?php else : ?>
							<?php // no rows found ?>
						<?php endif; ?>
				</div>
			</div>
			
		</div>
	</div>
</div>