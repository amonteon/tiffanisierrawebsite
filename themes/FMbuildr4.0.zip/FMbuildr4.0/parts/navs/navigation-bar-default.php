<?php
/**
 * The off-canvas menu uses the Off-Canvas Component
 *
 * For more info: http://jointswp.com/docs/off-canvas-menu/
 */
$logo = get_field('logo','options');
$alt_logo = get_field('alt_logo','options');
$tablet_logo = get_field('tablet_logo','options');
$mobile_logo = get_field('mobile_logo','options');
$phone = get_field('phone_number','options');
$alt_number = get_field('alt_number','options');
$fax_number = get_field('fax_number','options');
$email_address = get_field('email_address','options');
$address = get_field('address','options');
$google_map_link = get_field('google_map_link','options');
$google_map_embed = get_field('google_map_embed','options');
$topCTA = get_field('top_cta','options');
$topCTALink = get_field('top_cta_link','options');
$officeName = get_field('office_name','options');
$secondOfficeName = get_field('second_office_name','options');
$secondPhone = get_field('second_office_phone_number','options');

if(is_front_page()):
	$class = '';	
else:
	$styles = "position:fixed;";	
	$class = "is-fixed";	
endif;	
?>

<div data-sticky-container>
	<div class="<?=$class?> wait-js sticky-wrapper-navigation" data-sticky data-options="marginTop:0; stickyOn:small;" style="<?=$styles?> width:100%;">	
		<div class="grid-container nav-container">
			<div class="grid-x grid-padding-x align-middle align-center nav-grid">
				<div class="cell auto large-shrink logo-container show-for-large">
					<a href="<?php echo home_url(); ?>">
						<img class="main-logo" data-interchange="[<?=$mobile_logo['url'];?>, small], [<?=$tablet_logo['url'];?>, medium], [<?=$logo['url'];?>, large]" height="<?=$logo['height'];?>" width="<?=$logo['width'];?>" alt="<?=$logo['alt'];?>"/ >
						<img class="alt-logo"  data-interchange="[<?=$alt_logo['url'];?>, small], [<?=$alt_logo['url'];?>, medium], [<?=$alt_logo['url'];?>, large]" height="<?=$alt_logo['height'];?>" width="<?=$alt_logo['width'];?>" alt="<?=$alt_logo['alt'];?>"/ >
					</a>
				</div>
				<!-- UPPER BAR -->
				<div class="cell auto">
					<div class="upper-bar show-for-large">
						<div class="grid-container">
							<div class="grid-x">
								<div class="cell socialinks shrink">
									<?php echo do_shortcode('[socialLinks]');?>
								</div>
								<div class="cell auto text-right" id="location-tel-links">
									
									<div class="cta-dropdown-container">						
										<a class="primary button rounded hollow phone-button dropdown-select" data-toggle="select-option">Call Our Offices</a>
											<?php if ( have_rows( 'add_office_name_number', 'option' ) ) : ?>
												<div class="cta-dropdown-wrapper">
													<div id="select-option"  class="dropdown-pane grid-x grid-container" data-dropdown data-auto-focus="true" data-hover="true" data-hover-pane="true" data-alignment="center">
														<a class="cta-dropdown-links" href="tel:+1<?php echo _phone_num($phone);?>"><span><?= $officeName; ?></span><br><?=$phone;?></a>
														<?php while ( have_rows( 'add_office_name_number', 'option' ) ) : the_row(); ?>
															<?php $phoneNums = get_sub_field( 'office_phone_number' ); ?>
																<a href="tel:+1<?php echo _phone_num($phoneNums);?>" class="cta-dropdown-links"><span class="location-name"><?php the_sub_field( 'office_name' ); ?></span> <br><?=$phoneNums; ?></a>
														<?php endwhile; ?>
													</div>
												</div>
											<?php else : ?>
												<?php // no rows found ?>
											<?php endif; ?>
									</div>
								</div>
								<div class="cell shrink cta">
									<a href="<?=$topCTALink;?>" class="button primary rounded"><?=$topCTA;?></a> 
								</div>
							</div>	
						</div>
					</div>		
					<!-- TOP BAR -->
					<div class="lower-bar wait-js" id="top-bar-menu">
						<div class="grid-container">
							<div class="grid-x align-middle">
								
								<div class="cell shrink float-left mobile-hamburger-container default hide-for-large text-left ">		
									<!--  https://jonsuh.com/hamburgers/ for reference -->			
									<button class="hamburger hamburger--squeeze" type="button" data-toggle="off-canvas" >
									  <span class="hamburger-box">
									    <span class="hamburger-inner"></span>
									  </span>
									</button>				
								</div>
								<div class="cell auto large-shrink logo-container hide-for-large">
									<a href="<?php echo home_url(); ?>">
										<img class="main-logo" data-interchange="[<?=$mobile_logo['url'];?>, small], [<?=$tablet_logo['url'];?>, medium], [<?=$logo['url'];?>, large]" height="<?=$logo['height'];?>" width="<?=$logo['width'];?>" alt="<?=$logo['alt'];?>"/ >
										<img class="alt-logo"  data-interchange="[<?=$alt_logo['url'];?>, small], [<?=$alt_logo['url'];?>, medium], [<?=$alt_logo['url'];?>, large]" height="<?=$alt_logo['height'];?>" width="<?=$alt_logo['width'];?>" alt="<?=$alt_logo['alt'];?>"/ >
									</a>
								</div>
								
								<div class="cell shrink mobile-phone-number-container float-right default hide-for-large text-right">
									<button class="off-canvas-phone-toggle phone control" type="button" data-toggle="off-canvas-phone" ><i class="fa fa-phone" aria-hidden="true"></i></span>
									</button>		
									
<!-- 									<a href="tel:+1<?php echo _phone_num($phone)?>" class="phone control"><i class="fa fa-phone" aria-hidden="true"></i></a> -->
								</div>
								<div class="cell small-12 navigation-bar show-for-large">
									<div class="menu-centered">
										<?php joints_top_nav(); ?>
									</div>	
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="cell shrink anchor-phone-container show-for-large">
					<a class="anchored-phone-link" href="tel:+1<?php echo _phone_num($phone);?>"><?=$phone;?></a>
				</div>
			</div>
		</div>
	</div>
</div>