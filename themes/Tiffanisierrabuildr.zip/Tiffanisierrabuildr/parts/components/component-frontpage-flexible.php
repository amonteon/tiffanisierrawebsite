<?php	  

	
if( have_rows('flexible_section_fields') ):
  // loop through the rows of data
    while ( have_rows('flexible_section_fields') ) : the_row();

		if ( get_row_layout() == 'new_row'):
	
		$customID = get_sub_field( 'unique_id' );
		$customClass = get_sub_field('custom_classes');
		$data_attributes = get_sub_field('data_attributes');	
		$add_bg_images = get_sub_field('add_bg_images');
		$make_gradient = get_sub_field( 'make_it_gradient' );
		$type_of_row = get_sub_field('type_of_row');
		$add_column_padding = get_sub_field('add_column_padding');
		$bgImgs = get_sub_field('background_images');
		$fp_background_color = get_sub_field('fp_background_color');
		$fp_background_color_two = get_sub_field('fp_background_color_two');		
		$fp_parallax_images = get_sub_field('fp_parallax_images');		
		$interchangeImgs = dataInterchangeImgs($bgImgs);	
		$type_of_parallax = get_sub_field('type_of_parallax');	 
		$change_font_color = get_sub_field( 'change_text_color' );
		$new_font_color = get_sub_field( 'new_text_color' );
		$add_caption_to_bg = get_sub_field( 'fp_add_caption' );
		$countr=0;
 
		?>		
		<section id="<?=$customID;?>" class="fp-section-wrapper <?php if($add_caption_to_bg == true): ?> add-caption-to-bg <?php endif;?>">			
				<div class="fp-sections fp-section-background <?php if($fp_parallax_images): echo $type_of_parallax; endif;?>"  <?php if($add_bg_images): ?>data-interchange="<?=$interchangeImgs?>"<?php endif; ?>  <?php if(($add_bg_images && $make_gradient) == true): ?>style="background:linear-gradient(to bottom, <?=$fp_background_color;?>,<?=$fp_background_color_two;?> " <?php elseif($add_bg_images): ?>style="background:<?=$fp_background_color?>; background-repeat: no-repeat; background-size: cover;" <?php endif; ?> <?=$data_attributes?> >			 <div class="<?=$type_of_row?>">
					<div class="grid-x align-center align-middle <?=$customClass;?> <?=$add_column_padding?>" >
					<?php if( have_rows('columns') ):?>		
						<?php while ( have_rows('columns') ) : the_row(); ?>			
							<?php 
								// $add_slider = get_sub_field('add_slider');
								
								$colClasses = get_sub_field('custom_classes');
								$column_data_attribute = get_sub_field('column_data_attribute');
								$smCol = get_sub_field('sm_size');
								$mdCol = get_sub_field('md_size');
								$xmdCol = get_sub_field('xmd_size');							
								$lgCol = get_sub_field('lg_size');
								$xlgCol = get_sub_field('xlg_size');														
								
								$colContent = get_sub_field('column_content');
								$add_content = get_sub_field('add_content');							
								
								$add_background_image = get_sub_field('add_background_image');
								$background_image_cell = get_sub_field('background_image_cell');
								$interchangeImgInternal = dataInterchangeImgs($background_image_cell);
								$invert_slider= get_sub_field( 'invert_slider' );
								
									
							?>
							<div class="cell align-middle <?php if($change_font_color): ?> new-font-styles <?php endif;?> <?=$colClasses;?> small-<?=$smCol;?> medium-<?=$mdCol;?> xmedium-<?=$xmdCol;?> large-<?=$lgCol;?> xlarge-<?=$xlgCol?>"	<?=$column_data_attribute?> <?php if($background_image_cell && $add_background_image): ?> style="height:100%; background-size: cover; background-repeat: no-repeat;" <?php endif; ?>>
								<div class="cell-background align-middle" <?php if($background_image_cell && $add_background_image): ?> data-interchange="<?=$interchangeImgInternal?>" style="height:100%; background-repeat: no-repeat; background-size: cover;" <?php endif; ?><?php if($change_font_color): ?> style="color:<?=$new_font_color;?>;"<?php endif;?> >
																	
									<?php
										// check if the flexible content field has rows of data
										if( have_rows('add_content_column') ):									
										     // loop through the rows of data
										    while ( have_rows('add_content_column') ) : the_row();	$countr++;								
										        if( get_row_layout() == 'content_slider' ):		
										        	$column_slider_id = get_sub_field('column_slider_id');
										        	$slider_title = get_sub_field( 'section_title' );
										        	$slider_subheading = get_sub_field( 'content_slider_subheading' );
										        	$read_more_link = get_sub_field( 'read_more_link' );
													if(have_rows('content_slider_inner')): $ctr = 0; ?>
														<div class="fp-slider-container grid-container align-middle">
															<div class="grid-x grid-padding-x align-center align-middle">
																<div class="cell small-12 medium-10 large-5">
																	<span class="subheading text-center"><?=$slider_subheading;?></span>
																	<h2 class="text-center reviews-slider-title"><?=$slider_title; ?></h2>
																</div>
																<div class="cell small-12 medium-12 large-10">
																	<div class="swiper-container align-middle" id="<?=$column_slider_id?>">
																		<div class="swiper-wrapper">
																			<?php while(have_rows('content_slider_inner')): the_row(); 
																				$content = get_sub_field('content'); ?>
																				<div class="swiper-cell carousel-cell">
																					<div class="fp-carousel-slide-container text-center">
																						<div class="inner-slider-content">
																							<?=$content; ?>
																						</div>
																					</div>
																				</div>
																			<?php endwhile; ?>
																		</div>
																	</div>
																</div>
																<div class="cell small-10 medium-10 large-3 reviews-button-cell">
																		<?php if ( $read_more_link ) { ?>
																			<a class="button hollow white reviews-button" href="<?php echo $read_more_link['url']; ?>" target="<?php echo $read_more_link['target']; ?>"><?php echo $read_more_link['title']; ?></a>
																		<?php } ?>
																</div>
															</div>
														</div>
													<?php endif; ?>		
											<?php elseif ( get_row_layout() == 'accreditation_slider' ) : ?>
											<div class="accreditation-slider grid-container">
												<div class="grid-x grid-padding-x">
													<div class="cell">
														<?php if ( have_rows( 'accreditation_slider' ) ) :  ?>
															<div class="accreditation-slider logos-slider-<?=$countr;?>">
																<div class="swiper-wrapper">
																	<?php while ( have_rows( 'accreditation_slider' ) ) : the_row();?>
																		<?php $logo_image = get_sub_field( 'logo_image' ); ?>
																		<div class="swiper-slide">
																			<?php if ( $logo_image ) { ?>
																				<img src="<?php echo $logo_image['url']; ?>" alt="<?php echo $logo_image['alt']; ?>" />
																			<?php } ?>
																		</div>
																	<?php endwhile; ?>
																</div>
															</div>
														<?php endif; ?>
													</div>
												</div>
											</div>
										        										
										     <?php  elseif( get_row_layout() == 'wysiwyg_editor' ): 					        										        								$cell_content = get_sub_field('cell_content');	
										        	if($cell_content): echo $cell_content; endif;							
										        endif;									
										    endwhile;									
										else :									
										    // no layouts found									
										endif;									
									?>
									
								
								
								</div>
							</div>			
								
						<?php endwhile;?>						
					<?php endif;?>		
					</div>
				</div>
			</div>		
		</section>	
		
		<?php elseif ( get_row_layout() == 'homepage_slider' ) : ?>
		<section class="hp-procedures-slider-section">
			
			<?php if ( have_rows( 'slider_content' ) ) : ?>
				<div class="homepage-procedures-slider">
					<div class="swiper-wrapper">
						<?php while ( have_rows( 'slider_content' ) ) : the_row(); $ctr = 0; ?>
							<?php $slider_title = get_sub_field( 'slider_title' ); ?>
							<?php $slider_subheading = get_sub_field( 'slider_subheading' ); ?>
							<?php $slider_background_image_images = get_sub_field( 'slider_background_image' ); 
									$interchangeSliderImgs = dataInterchangeImgs($slider_background_image_images);	
							?>
							<div class="swiper-slide">
								<div class="procedures-slider-bg-img" data-interchange="<?=$interchangeSliderImgs;?>" ></div>
								<div class="grid-container">
									<div class="grid-x align-middle procedures-content-wrapper">
										<div class="cell small-12 procedure-slider-title">
											<span class="procedure-subheading"><?=$slider_subheading;?></span>
											<h2><?=$slider_title;?></h2>
										</div>
										<?php if ( have_rows( 'slider_inner_content' ) ): ?>
											<?php while ( have_rows( 'slider_inner_content' ) ) : the_row(); ?>
												<?php if ( get_row_layout() == 'slider_inner' ) : ?>
												<div class="inner-content-container align-middle mobileExpand">
													<div class="cell small-12 large-8 content-cell">
														<?php the_sub_field( 'slider_content' ); ?>
													</div>
												
													<div class="cell small-12 large-5 procedure-button-cell">
														<?php $slider_button = get_sub_field( 'slider_button' ); ?>
														<?php if ( $slider_button ) { ?>
															<a class="button rounded white" href="<?php echo $slider_button['url']; ?>" target="<?php echo $slider_button['target']; ?>"><?php echo $slider_button['title']; ?></a>
														<?php } ?>
													</div>
													<?php if ( have_rows( 'slider_extra_links' ) ) : ?>
														<div class="cell small-12 large-7 extra-links-cell">
															<div class="grid-x">
																<?php while ( have_rows( 'slider_extra_links' ) ) : the_row(); ?>
																	<div class="cell small-12 medium-6">
																		<?php $extra_link = get_sub_field( 'extra_link' ); ?>
																		<?php if ( $extra_link ) { ?>
																			<a class="other-links" href="<?php echo $extra_link['url']; ?>" target="<?php echo $extra_link['target']; ?>"><?php echo $extra_link['title']; ?></a>
																		<?php } ?>
																	</div>
																<?php endwhile; ?>
															</div>
														</div>
													<?php else : ?>
														<?php // no rows found ?>
													<?php endif; ?>
												</div>
												<?php endif; ?>
											<?php endwhile; ?>
										<?php endif; ?>
									</div>
								</div>
							</div>
						<?php endwhile; ?>
					</div>
					<div class="swiper-button-next"></div>
					<div class="swiper-button-prev"></div>
					<div class="swiper-procedures-scrollbar"></div>
				</div>
			<?php else : ?>
				<?php // no rows found ?>
			<?php endif; ?>

		</section>
		
		
		<?php elseif ( get_row_layout() == 'featured_doctors' ) : ?>
			<?php $doctor_section_id = get_sub_field( 'section_id' ); ?>
			<?php $doctor_section_classes = get_sub_field( 'section_classes' ); ?>
			
		<section class="featured-doctors-section">			
			<div class="grid-x">
				<?php if ( get_sub_field( 'add_featured_block' ) == 1 ): ?>
					<?php if ( have_rows( 'featured_block_fields' ) ): $ftdoctorToggle = 0; ?>
						<?php while ( have_rows( 'featured_block_fields' ) ) : the_row(); $ftdoctorToggle++; ?>
							<div id="ft-block-<?=$ftdoctorToggle;?>" class="cell doctor-block small-12 large-auto hideDoctor">
								<div class="doctor-service-inner">
									<?php if ( get_row_layout() == 'featured_block' ) : ?>
										<?php $featured_subheading = get_sub_field( 'block_subheading' ); ?>
										<?php $featured_heading = get_sub_field( 'block_heading' ); ?>
										<?php $featured_block_image_images = get_sub_field( 'featured_block_image' );
												$intechangeDoctorImgs = dataInterchangeImgs($featured_block_image_images);
										 ?>
										<div class="doctor-bg-image ft-bg-img" data-interchange="<?=$intechangeDoctorImgs;?>"></div>
										<div class="doctor-content ft-doctor-content grid-x grid-padding-x align-middle align-center">
											<div class="cell small-12 medium-12 large-12 doctor-cell">
												<span class="doctor-service-subheading" ><?=$featured_subheading; ?> </span>
												<h4 class="doctor-service-title ft-title" ><?=$featured_heading; ?> </h4>
											</div>
										</div>
										
									<?php endif; ?>
								</div>
							</div>
						<?php endwhile; ?>
					<?php endif; ?>
				
				<?php else :?>
				
				
				<?php endif; ?>
																																																																																																																																				
				<?php if ( have_rows( 'doctors' ) ) : $doctorToggle = 0;?>
					<?php while ( have_rows( 'doctors' ) ) : the_row(); $doctorToggle++?>
						<div id="doctor-block-<?=$doctorToggle;?>"class="cell small-12 large-auto doctor-block hideDoctor" data-toggler="viewDoctor hideDoctor">
							<div class="doctor-service-inner">
								<?php $doctor_name = get_sub_field( 'doctor_name' ); ?>
								<?php $doctor_page_link = get_sub_field( 'doctor_page_link' ); ?>		
								<?php $doctor_image_images = get_sub_field( 'doctor_image' ); 
									$intechangeDoctorsImgs = dataInterchangeImgs($doctor_image_images);
								?>
								<div class="doctor-bg-image" data-interchange="<?=$intechangeDoctorsImgs;?>"></div>
								<div class="doctor-content grid-x grid-padding-x align-middle align-center">
									<div class="cell small-12 medium-12 large-12 doctor-cell">
										<h4 class="doctor-service-title" ><?=$doctor_name; ?> </h4>
										<a class="more-toggle" data-toggle="doctor-block-<?=$doctorToggle;?> expand-text<?=$doctorToggle;?> collapse-text<?=$doctorToggle;?> "><span id="expand-text<?=$doctorToggle;?>" class="show" data-toggler="hide show">Click to expand <i class="fal fa-arrow-circle-down"></i></span><span id="collapse-text<?=$doctorToggle;?>" class="hide" data-toggler="hide show">Click to collapse <i class="fal fa-arrow-circle-up"></i></span></a> 
										<div class="doctor-excerpt">
											<?php the_sub_field( 'doctor_description' );?>
											<a href="<?php echo $doctor_page_link["url"];?>" class=""><?=$doctor_page_link["title"];?></a>
										</div>				
										
										
									</div>
								</div>
							</div>
						</div>
					<?php endwhile; ?>
				<?php endif; ?>		
			</div>
		</section>
		
		<?php elseif ( get_row_layout() == 'hp_request_consultation' ) : ?>
		<?php 
				$consultationContent = get_sub_field( 'hp_content');
				$consultationBgImgs = get_sub_field( 'hp_background_image' );
				$interchangeImgs = dataInterchangeImgs($consultationBgImgs);
				$consultationButton = get_sub_field( 'hp_button_text' );
		?>
		<section class="hp-request-consultation">
			<div class="grid-x consultation-grid-container align-middle align-center" data-interchange="<?=$interchangeImgs;?>" style="background-attachment:fixed;">	
				<div class="cell small-12 medium-12 large-12 ">	
					<div class="grid-x grid-container grid-padding-x align-middle align-center entry-content">
						<div class="cell small-12 medium-10 xmedium-8 large-8 text-center">
							<?=$consultationContent;?>
							<a class="primary button hollow white" href="<?php echo $consultationButton['url']; ?>" target="<?php echo $consultationButton['target']; ?>"><?php echo $consultationButton['title']; ?></a>
						</div>
					</div>
				</div>
			</div>
		</section>
		
		<?php elseif ( get_row_layout() == 'omni_background_logo' ) : ?>
		<section class="omni-bg-logo-img">
			
			<?php $background_logo_images = get_sub_field( 'background_logo' ); 
					$interchangeLogoImgs = dataInterchangeImgs($background_logo_images);
			?>
			<?php if ( $background_logo_images ) :  ?>
				<div class="omni-bg-img" data-interchange="<?=$interchangeLogoImgs;?>"></div>
			<?php endif; ?>
		</section>
		<?php elseif ( get_row_layout() == 'hp_fifty_fifty' ) : ?>
			<section class="hp-fifty-fifty-section">
				<div class="grid-container">
					<div class="grid-x grid-padding-x align-center align-middle hp-fifty-container">
						<div class="cell small-12 xmedium-6 large-6 small-order-2 xmedium-order-1 fifty-content-cell">
							<?php if ( have_rows( 'content_left' ) ): ?>
								<?php while ( have_rows( 'content_left' ) ) : the_row(); ?>
									<?php if ( get_row_layout() == 'content_fields' ) : ?>
										<span class="subheading"><?php  the_sub_field( 'content_subheading' ); ?></span>
										<h2><?php the_sub_field( 'content_heading' ); ?></h2>
										<?php the_sub_field( 'content' ); ?>
										<?php $content_link = get_sub_field( 'content_link' ); ?>
										
										<a class="button rounded primary" href="<?php echo $content_link['url']; ?>" target="<?php echo $content_link['target']; ?>"><?php echo $content_link['title']; ?></a>
									
									<?php endif; ?>
								<?php endwhile; ?>
							<?php else: ?>
								<?php // no layouts found ?>
							<?php endif; ?>
						</div>
						<div class="cell small-12 xmedium-6 large-6 fifty-image-cell small-order-1 xmedium-order-2">
							<div class="fifty-img-container">
								<?php 
									$content_right = get_sub_field( 'content_right' ); 
									$interchangeFiftyImgs = dataInterchangeImgs($content_right);
								?>
								<?php if ( $content_right ) { ?>
									<img data-interchange="<?=$interchangeFiftyImgs;?>" alt="<?php echo $content_right['alt']; ?>" />
								<?php } ?>
							</div>
						</div>
					</div>
				</div>	
			</section>
			
		<?php elseif ( get_row_layout() == 'fifty_content_fifty_twentytwenty' ) : ?>
			<?php 
				$ff_content_heading = get_sub_field( 'section_heading' );
				$ff_content_subheading = get_sub_field( 'section_subheading' );
				$image_before = get_sub_field( 'image_before' );
				$image_after = get_sub_field( 'image_after' ); 
			?>
		<section class="hp-twenty-twenty">
			<div class="grid-container">
				<div class="grid-x grid-padding-x align-center align-middle">
					<div class="cell small-12 medium-10 xmedium-6 large-6 image-left small-order-1 large-order-2">
						<div id="twentytwenty-container" class='twentytwenty-container'>
								<img src="<?php echo $image_before['url']; ?>" alt="<?php echo $image_before['alt']; ?>" />
								<img src="<?php echo $image_after['url']; ?>" alt="<?php echo $image_after['alt']; ?>" />
						</div>
					</div>
						
					<div class="cell small-12 medium-10 xmedium-6 large-6 content-right small-order-3 large-order-3">
						<div class="section-heading">
							<span class="subheading"><?=$ff_content_subheading;?></span>
							<h2><?=$ff_content_heading;?></h2>
						</div>
						<?php if ( have_rows( 'section_content' ) ): ?>
							<?php while ( have_rows( 'section_content' ) ) : the_row(); ?>
								<?php if ( get_row_layout() == 'content' ) : ?>
								
									<?php 
										$section_content = get_sub_field( 'content' ); 
										$link = get_sub_field( 'link' ); 
									?>
									<div class="grid-x section-content-container grid-padding-x">
										<div class="cell small-12 medium-12 xlarge-10 main-content-cell">
											<div class="main-content-container"><?=$section_content;?></div>
											<a class="primary button rounded" href="<?php echo $link['url']; ?>" target="<?php echo $link['target']; ?>"><?php echo $link['title']; ?></a>
										</div>
									</div>
									<?php endif; ?>
								<?php endwhile; ?>
							<?php endif; ?>
						
					</div>
				</div>
			</div>
		</section>

		<?php elseif(get_row_layout() == 'instagram_carousel'): 
			$instagram_user_id = get_sub_field( 'instagram_user_id' );
			$instagram_access_token = get_sub_field('instagram_access_token');
			$added_caption = get_sub_field('added_caption');
		?>
			
			<section class="instagram-gallery animate" id="instagram-gallery" data-anim-type="fadeIn" data-anim-delay="400">
		
			    <?php
					// Supply a user id and an access token
					$userid = $instagram_user_id;
			
					$accessToken = $instagram_access_token;
					$itemCount = 0;
						
					// Gets our data
					function fetchData( $api_url ){
			        $connection_c = curl_init(); // initializing
			        curl_setopt( $connection_c, CURLOPT_URL, $api_url ); // API URL to connect
			        curl_setopt( $connection_c, CURLOPT_RETURNTRANSFER, 1 ); // return the result, do not print
			        curl_setopt( $connection_c, CURLOPT_TIMEOUT, 20 );
			        $json_return = curl_exec( $connection_c ); // connect and get json data
			        curl_close( $connection_c ); // close connection
			        return json_decode( $json_return ); // decode and return
			    }
			
					// Pulls and parses data.
					$result = fetchData("https://api.instagram.com/v1/users/{$userid}/media/recent/?access_token={$accessToken}");
					
				?>
			
				<!-- Wrapper for slides -->
				<div id="instagram-carousel">				
					<?php foreach ($result->data as $post): $itemCount ++;?>								
							<div class="carousel-cell">
								<div class="grid-x align-middle box" style="background-image:url(<?=$post->images->standard_resolution->url ?>); background-size:cover; background-position: center center; ">
									<div class="cell small-12 box-inner">
										<!-- Renders images. @Options (thumbnail,low_resoulution, high_resolution) -->						
										<a data-fancybox="instagram"  data-caption='<p class="cap"><?php echo preg_replace('/[^A-Za-z0-9 !@#$%^&*().]/u','', strip_tags($post->caption->text));?></p><p class="caplink"><?=$added_caption?></p>' href="<?=$post->link ?>" target="_blank" rel="nofollow" data-fancybox-group="gallery" title="<?php echo $post->caption->text ?>">	
											<img src="<?=$post->images->standard_resolution->url ?>" style="opacity:0;"
											width="427" height="427" alt="<?php echo $post->caption->text ?>" >
										</a>
									</div>
								</div>
							</div> <!-- end .box -->			
					<?php endforeach ?> 						
				</div>					
					
			</section>
			
		<?php endif;?>		
	<?php endwhile; ?>	
<?php else : ?>

no layouts found

<?php  // no layouts found
endif; ?>



  